
export const data = [
    {
      id: 1,
      name: "Topic 1",
      color: "orange",
      link:'/detailRoute/histoire'
    },
    {
      id: 2,
      name: "Topic 2",
      color: "blue",
      link:'/detailRoute/geographie'
    },
    {
      id: 3,
      name: "Topic 3",
      color: "gray",
      link:'/detailRoute/chemie'
    },
    {
      id: 4,
      name: "Topic 4",
      color: "black",
      link:'/detailRoute/biologie'
    },
    {
      id: 5,
      name: "Topic 5",
      color: "green",
      link:'/detailRoute/physique'
    },
    {
      id: 6,
      name: "Topic 6",
      color: "red",
      link:'/detailRoute/art'
    },
    {
      id: 7,
      name: "Topic 7",
      color: "purple",
      link:'/detailRoute/sport'
    },
    {
      id: 8,
      name: "Topic 8",
      color: "yellow",
      link:'/detailRoute/litterature'
    },
    {
      id: 9,
      name: "Topic 9",
      color: "#df00ff",
      link:'/detailRoute/cultureGeneral'
    }
  ];