
export const data = [
    {
      id: 1,
      name: "Histoire",
      color: "orange",
      link:'/histoireDetail'
    },
    {
      id: 2,
      name: "Geographie",
      color: "blue",
      link:'/histoireDetail'
    },
    {
      id: 3,
      name: "Chemie",
      color: "gray",
      link:'/histoireDetail'
    },
    {
      id: 4,
      name: "Biologie",
      color: "black",
      link:'/histoireDetail'
    },
    {
      id: 5,
      name: "Physique",
      color: "green",
      link:'/histoireDetail'
    },
    {
      id: 6,
      name: "Art",
      color: "red",
      link:'/histoireDetail'
    },
    {
      id: 7,
      name: "Sport",
      color: "purple",
      link:'/histoireDetail'
    },
    {
      id: 8,
      name: "Litterature",
      color: "yellow",
      link:'/histoireDetail'
    },
    {
      id: 9,
      name: "Cultural",
      color: "#df00ff",
      link:'/histoireDetail'
    }
  ];