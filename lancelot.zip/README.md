# bookdriver_frontend

Frontend for Bookdriver Project.

## Steps to deploy
1. npm install
2. npm run build

## For development
1. npm install
2. npm start