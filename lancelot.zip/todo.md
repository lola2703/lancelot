* Übersetzungen
* Mailtexte für PW vergessen / Registrierung
* Lehrer Statistik
* Lehrernachricht an Schüler